#include "types.h"
#include "user.h"
#include "stat.h"
#include "param.h"
#include "pstat.h"

int
numone(){
    int count = 0;
    int init = 1;
    while(count < 500000000000){
        init = init * 2;
        count++;
    }
    return count;
}

int
main(int argc, char *argv[])
{
	struct pstat p;

	int tickets[3] = {30,20,10};
  int pids[3];
  for (int i = 0; i < 3; i++ ){
        pids[i] = fork();
        if (pids[i] == 0)
        {
            if(settickets(tickets[i]) < 0){
               exit();
            }
            while(1){
                numone();
                exit();
            }
        }
    }

    int starting = uptime();
    sleep(600);
    printf(1,"Time: %d\n", uptime() - starting);

    if (getpinfo(&p)<0){
    	exit();
    }
    for(int i = 2; i < NPROC; i++){
      if(p.inuse[i]){
        printf(1, "Tickets: %d Pid: %d Inuse: %d Ticks: %d\n", p.tickets[i], p.pid[i], p.inuse[i], p.ticks[i]);
      }
	   }
    for (int x = 0; x < 3; x++ ){
        kill(pids[x]);
        wait();
    }
    exit();
}
