#include "types.h"
#include "user.h"
#include "stat.h"
#include "param.h"
#include "pstat.h"
#include "fcntl.h"

void onenum()
{
  int i = 0;
  int x = 0;
  int y = 0;
  for(i = 0; i < 100; ++i)
    {for(x = 0; x < 550000; ++j){
  	  y = x % 10;
  	  y+=1;
	   }
  }
}

int
main(int argc, char *argv[]){
  struct pstat p;
  int nt[] = {10,20,30};
  int pid[3];
  int time = 0;
  int ticks[3] = {0,0,0};
  pid[0] = getpid();
  settickets(nt[0]);
  int i;

  for(i=1;i<3;i++){
    pid[i]=fork();
    if(pid[i]==0){
      for (;;){
      	onenum();
      }
    }
    else{
      settickets(nt[i]);
    }
  }

  while(time < 2000){
    if(getpinfo(&p)!=0){
      printf(1,"failed\n");
      for (i = 0; pid[i] > 0; i++){
        kill(pid[i]);
      }
      wait();
      exit();
    }

    int xx;
    int pid;
    for(i = 0; i < 3 ;i++){
      pid = pid[i];
      for(xx = 0;xx < NPROC; xx++){
        if(p.pid[xx] == pid){
      	  ticks[i]=p.ticks[xx];}
      }
    }

  for(i=0;i<3;i++){
      printf(1,"%d, ",ticks[i]);
    }
    printf(1,"\n");
    onenum();
    time++;
  }
  wait();
  exit();

}
